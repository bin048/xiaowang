---
类型: 技能
名称: TypeScript
tags: [技能]
---

# TypeScript

> 技能笔记 · 关联 2 人

## 会这项的人

- [[白露晞]]
- [[郑执野]]
